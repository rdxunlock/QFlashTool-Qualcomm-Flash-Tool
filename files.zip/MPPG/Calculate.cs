namespace MPPG
{
	public static class Calculate
	{
		public static string firehose()
		{
			string text = "data\\firehose\\";
			return text + M3.id + ".mbn";
		}
	}
}
