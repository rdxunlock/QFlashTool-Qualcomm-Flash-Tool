internal class ILLicenseModule
{
}
