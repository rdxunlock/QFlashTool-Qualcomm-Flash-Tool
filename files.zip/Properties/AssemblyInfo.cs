using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyProduct("Qualcomm Premium Tool")]
[assembly: AssemblyTitle("Qualcomm Premium Tool")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(true)]
[assembly: AssemblyCompany("")]
[assembly: Guid("6079bd68-e1e8-4757-a9f3-e3a2f28f10e3")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyCopyright("Copyright ©  2017")]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("1.0.0.0")]
